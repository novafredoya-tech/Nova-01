import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';
import '../models/message.dart';

class ChatProvider with ChangeNotifier {
  final _uuid = const Uuid();
  final List<Message> _messages = [];
  bool _isLoading = false;
  String? _error;
  bool _hasContext = false;
  StreamSubscription? _messageStream;

  List<Message> get messages => List.unmodifiable(_messages);

  bool get isLoading => _isLoading;

  String? get error => _error;

  bool get hasContext => _hasContext;

  // Simulated streaming response - replace with actual API call
  Future<void> sendMessage(String content) async {
    if (content.trim().isEmpty) return;

    try {
      _error = null;

      // Add user message
      _messages.add(Message(
        id: _uuid.v4(),
        role: 'user',
        content: content,
        createdAt: DateTime.now(),
      ));
      notifyListeners();

      _isLoading = true;
      notifyListeners();

      // Simulate API streaming response
      final responseId = _uuid.v4();
      String responseText = '';

      await Future.delayed(const Duration(seconds: 1));

      // In production, this would be replaced with actual API streaming
      const response = "I understand you're asking about that. Let me help you...";

      // Simulate streaming each word
      for (final word in response.split(' ')) {
        await Future.delayed(const Duration(milliseconds: 100));
        responseText += '$word ';

        _messages.removeWhere((m) => m.id == responseId);
        _messages.add(Message(
          id: responseId,
          role: 'assistant',
          content: responseText.trim(),
          createdAt: DateTime.now(),
          isStreaming: true,
        ));
        notifyListeners();
      }

      // Final message without streaming flag
      _messages.removeWhere((m) => m.id == responseId);
      _messages.add(Message(
        id: responseId,
        role: 'assistant',
        content: responseText.trim(),
        createdAt: DateTime.now(),
      ));
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  void deleteMessage(String messageId) {
    _messages.removeWhere((m) => m.id == messageId);
    notifyListeners();
  }

  void clearConversation() {
    _messages.clear();
    notifyListeners();
  }

  // Call this when navigating away
  @override
  void dispose() {
    _messageStream?.cancel();
    super.dispose();
  }

  // Check context availability from API
  Future<void> checkContext() async {
    try {
      // TODO: Replace with actual API call
      await Future.delayed(const Duration(seconds: 1));
      _hasContext = true;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      notifyListeners();
    }
  }
}
