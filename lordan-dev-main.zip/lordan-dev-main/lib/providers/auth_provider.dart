import 'package:flutter/material.dart';

/// COMPONENT: AuthProvider
/// Mock authentication provider with no real backend integration
class AuthProvider extends ChangeNotifier {
  // Authentication state
  String? _email;
  String _plan = 'Free';
  bool _isLoading = false;

  // Getters
  String? get email => _email;
  String get plan => _plan;
  bool get isLoading => _isLoading;
  bool get isSignedIn => _email != null;

  /// COMPONENT: Mock Email Sign In
  /// Simulates email authentication with loading state
  Future<void> mockSignInEmail(String email) async {
    if (_isLoading) return;

    _isLoading = true;
    notifyListeners();

    // Simulate network delay
    await Future.delayed(const Duration(seconds: 2));

    _email = email;
    _isLoading = false;
    notifyListeners();
  }

  /// COMPONENT: Mock Google Sign In
  /// Simulates Google OAuth with loading state
  Future<void> mockSignInGoogle() async {
    if (_isLoading) return;

    _isLoading = true;
    notifyListeners();

    // Simulate network delay
    await Future.delayed(const Duration(seconds: 2));

    _email = 'user@gmail.com';
    _isLoading = false;
    notifyListeners();
  }

  /// COMPONENT: Mock Apple Sign In
  /// Simulates Apple Sign In with loading state
  Future<void> mockSignInApple() async {
    if (_isLoading) return;

    _isLoading = true;
    notifyListeners();

    // Simulate network delay
    await Future.delayed(const Duration(seconds: 2));

    _email = 'user@icloud.com';
    _isLoading = false;
    notifyListeners();
  }

  /// COMPONENT: Mock Sign Out
  /// Simulates sign out process with loading state
  Future<void> mockSignOut() async {
    if (_isLoading) return;

    _isLoading = true;
    notifyListeners();

    // Simulate network delay
    await Future.delayed(const Duration(milliseconds: 800));

    _email = null;
    _isLoading = false;
    notifyListeners();
  }

  /// COMPONENT: Set Plan (for demo purposes)
  /// Updates the user's plan status
  void setPlan(String newPlan) {
    _plan = newPlan;
    notifyListeners();
  }

  /// COMPONENT: Reset Auth State
  /// Resets all authentication state (useful for testing)
  void reset() {
    _email = null;
    _plan = 'Free';
    _isLoading = false;
    notifyListeners();
  }
}