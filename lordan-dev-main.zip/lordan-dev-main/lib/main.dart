import 'dart:developer' as developer;

import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:lordan_v1/providers/stats_provider.dart';
import 'package:lordan_v1/service/supabase_service.dart';
import 'dart:async';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'theme.dart';

import 'utils/functions.dart';
import 'utils/go_router.dart';

import 'providers/auth_provider.dart';
import 'providers/user_provider.dart';
import 'providers/chat_provider.dart';

Future<void> main() async {
  await runZonedGuarded<Future<void>>(() async {
    WidgetsFlutterBinding.ensureInitialized();

    await dotenv.load(fileName: ".env");

    // Global error handling
    FlutterError.onError = (details) {
      developer.log(
        'Flutter framework error: ${details.exceptionAsString()}',
        name: 'FlutterError',
        error: details.exception,
        stackTrace: details.stack,
      );
    };

    await Supabase.initialize(
      url: dotenv.env['SUPABASE_URL']!,
      anonKey: dotenv.env['SUPABASE_ANON_KEY']!,
    );

    runApp(
      MultiProvider(
        providers: [
          ChangeNotifierProvider<AuthProvider>(create: (_) => AuthProvider()),
          ChangeNotifierProvider<UserProvider>(create: (_) => UserProvider()),
          ChangeNotifierProvider<ChatProvider>(create: (_) => ChatProvider()),
          ChangeNotifierProvider(create: (_) => StatsProvider(SupabaseService())),
        ],
        child: const LordanApp(),
      ),
    );
  }, (Object error, StackTrace stack) {
    logError('Uncaught zone error', error);
    // ignore: avoid_print
    print(stack);
  });
}

class LordanApp extends StatelessWidget {
  const LordanApp({super.key});

  @override
  Widget build(BuildContext context) {
    // The router exported from utils/go_router.dart uses providers for guards.
    return Consumer<UserProvider>(builder: (context, themeProvider, child) {
      return MaterialApp.router(
        title: 'Lordan',
        // themeMode: themeProvider.themeMode,
        theme: lightTheme,
        // darkTheme: darkTheme,
        routerConfig: router,
      );
    });
  }
}
